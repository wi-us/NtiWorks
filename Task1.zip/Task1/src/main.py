from interface import *

root.mainloop()