import tkinter as tk
from tkinter import ttk
from Interface3 import *
import database as data
import datetime

root.mainloop()